/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;
import static data.DataModel.day;
import java.time.LocalDate;
import java.time.YearMonth;
import javax.swing.JTextArea;

/**
 *
 * @author grego
 */
public class Date {
    LocalDate firstDate;
    String month;
    String[] months = new String[12];
    Integer[] monthNums = new Integer[12];
    Integer[] days = new Integer[12];
    
    int year;
    int monthNum;
    int numberOfDays;
    
    String lastDate;
    String endDate;
    YearMonth ending;
    
    String beginDate;
    String startDate;
    YearMonth starting;
    int startDayOfMonth = 5;
   int spaces = startDayOfMonth;
  
    
   public Date(String month, int year)
   {
       
       this.month = month;
       this.year = year;
 
               for(int x = 0; x < months.length; x++)
               {
                   if(month.equals(DataModel.month[x]))
                   {
                       this.month = DataModel.month[x];
                       this.monthNum = DataModel.monthNumbers[x];
                   }
                   
               }

       firstDate = LocalDate.of(this.year, monthNum, 1);
   }
   public Date(int year)
   {
       this.year = year;
       this.months = DataModel.month;
       this.monthNums = DataModel.monthNumbers;
       this.days = DataModel.days;
   }
   
   
    
   public void calculateLastDate()
   {
          ending = YearMonth.from(firstDate);
          endDate = ending.atEndOfMonth().toString();
          lastDate = endDate.substring(endDate.length()-2);
   }
    
   public void calculateFirstDate()
   {
           starting = YearMonth.from(firstDate);
           
   }

   public String toString()
   {
       calculateLastDate();
       return "Selected Year: " + year + "\n"+
              "Selected Month: "  + month + "\n"+
              "Selected Month Number "+ monthNum + "\n"+
              "First Day of the Month: " + firstDate.getDayOfWeek() + "\n" +
              "Number of Days in: " + month +", "+ year + ": " + lastDate;
              
   }
   public String yearToString()
   {
       String message = "Selected Year : " + year + "\n\n";
       
       for(int x = 0; x<months.length; x++)
       {
          firstDate = LocalDate.of(this.year, monthNums[x], 1);
          calculateLastDate();
          message += "Number of days in " + months[x] + ": " + lastDate + "\n" +
                      "First Day of the Month : " + firstDate.getDayOfWeek() + "\n\n" ;;
           
       }
       
       return message;
   }
   
   public void displayCalander(JTextArea text)
   {
    
      for(int x = 0; x< DataModel.monthNumbers.length; x++)
      {
          YearMonth ym = YearMonth.of(year, DataModel.monthNumbers[x]);
        
        text.append("Year: " + year + "\n"+
                    "Month " + DataModel.month[x]);
        text.append("\n");
        text.append("Sun Mon Tue Wed Thu Fri Sat");
        text.append("\n");
        
        //count for start of week
        int counter = 1;

        int dayValue = LocalDate.of(year, DataModel.monthNumbers[x], 1).getDayOfWeek().getValue();
        if (dayValue != 7)
            //spaces for before the start of calandar.
            for (int i = 0; i < dayValue; i++, counter++) {
                text.append("   ");
            }


        for (int i = 1; i <= ym.getMonth().length(ym.isLeapYear()); i++, counter++) {
                 text.append("  " + i);

            // linebreak if the value of the counter is multiple of 7
            if (counter % 7 == 0) {
                text.append("\n");
            }
        }
        text.append("\n");
      }
      
   }
}
