/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import javax.swing.JTextArea;

/**
 *
 * @author grego
 */
public class SpecialDate {
    int day;
    int month;
    int year;
    String label;
    
    
    public SpecialDate(int day, int month, int year, String label)
    {
        this.day = day;
        this.month = month;
        this.year = year;
        this.label = label;
    }
    
    public String toString(JTextArea text)
    {
        String thing = text.getText();
        
        
        return thing;
       
    }
}
