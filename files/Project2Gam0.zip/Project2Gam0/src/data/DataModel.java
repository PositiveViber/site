/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.util.ArrayList;

/**
 *
 * @author grego
 */
public class DataModel {
           
    public static String day[]   = { "SUN","MON","TUE","WED","THU","FRI","SAT" } ;  
    public static String month[] = { "JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER" } ;   
    public static String year[] = {"2000", "2001", "2002" , "2003", "2004" , "2005" , "2006" , "2007" , "2008" , "2009", "2010" ,"2011" ,"2012", "2013" , "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023" ,"2024","2025", "2026", "2027", "2028"};
    public static Integer monthNumbers[] = {1,2,3,4,5,6,7,8,9,10,11,12};
    public static Integer days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    public static Date date1;
    public static Date date2;
            
}
class Months{
    
    
}
