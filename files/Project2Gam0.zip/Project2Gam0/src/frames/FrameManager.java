package frames;



import java.awt.Dimension;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author grego
 */
public class FrameManager {
    private static JFrame startFrame;
     
     private static Dimension minimumDimension;
     //NOTE: The minimumDimension of ALL JFrames should be set using the initial size of the startFrame.
     //       See the addFrameToFrameList method.
     
     private static ArrayList<JFrame> frameList;
     
     public FrameManager(JFrame startFrame)
     {
        
        this.startFrame = startFrame;
        
        minimumDimension = new Dimension(startFrame.getWidth(), startFrame.getHeight());
        
        JFrame tempFrame;
        
        frameList = new ArrayList<JFrame>();
        
        addFrameToFrameList(startFrame, "Main");       
        addFrameToFrameList(new frames.Game0Frame(), "Game0");
        addFrameToFrameList(new frames.Game1Frame(), "Game1");
        addFrameToFrameList(new frames.Game2Frame(), "Game2");
        addFrameToFrameList(new frames.Game3Frame(), "Game3");
        addFrameToFrameList(new frames.Game4Frame(), "Game4");
        addFrameToFrameList(new AboutFrame(), "About Frame");
        addFrameToFrameList(new DebugFrame(), "Debug Frame");
        //addAnswerFrameToFrameList(new gameAnswerMultiple(), "Game Answer");

        
     }
    
     public static void addFrameToFrameList(JFrame theFrame, String theName) {
        JFrame tempFrame = theFrame;
        tempFrame.setName(theName);
        tempFrame.setMinimumSize(minimumDimension);
        tempFrame.setMaximumSize(minimumDimension);  
        
        frameList.add(tempFrame);
    }
 
    
    public static void showAllFrameNames() {
        for (int i = 0; i < frameList.size(); i++) {
            System.out.print(" "+i+".   ");
            System.out.println("    frameList.get("+i+").getName()  "+frameList.get(i).getName());
        }
    }
    
    public static String getAllFrameNames() {
        String answer = new String();
        for (int i = 0; i < frameList.size(); i++) {
            
            answer += " "+i+".   "+frameList.get(i).getName()+"\n";
        }
        return answer;
    }
         
      public static void displayFrame(JFrame oldFrame, String nameOfNewFrame) {
       /*
        the displayFrame method makes certain that only one JFrame is visible
        at any time
        */ 
        
//        System.out.println("   displayFrame");
//        System.out.println("oldFrame.getLocation()  " + oldFrame.getLocation());
//        System.out.println("oldFrame.getSize()  " + oldFrame.getSize());
//        
//        System.out.println("   oldFrame.getName()  "+oldFrame.getName());
//        System.out.println("    frameList.size()  "+ frameList.size());
        
        boolean newFrameFound = false;
        
        for (int i = 0; i < frameList.size(); i++) {
//            System.out.println("i "+i);
//            System.out.println(" frameList.get(i).getName()  "+frameList.get(i).getName());
            if (nameOfNewFrame.equals(frameList.get(i).getName())) {
                newFrameFound = true;
                
                frameList.get(i).setLocation(oldFrame.getX(), oldFrame.getY());
                frameList.get(i).setSize(oldFrame.getSize());

                frameList.get(i).setVisible(true);
                oldFrame.setVisible(false);
                
                
                System.out.println("in FrameManager.displayFrame      -----    "+frameList.get(i).getName());
                
                //just in case there are two elements in frameList with the same name
                break;
            }
        }
        
        if ( newFrameFound == false) {
            
            System.out.println("\n\nERROR: in Utility.displayFrame could not find '"+ nameOfNewFrame +"'\n\n");
            
            //  JOptionPane.showMessageDialog(oldFrame, "ERROR: \n\n Could not find '"+ nameOfNewFrame +"' \nin FrameManager constructor.");
             
            JOptionPane.showMessageDialog(oldFrame,
                "Could not find '"+ nameOfNewFrame +"' \nin FrameManager constructor.",
                "Misssing Frame Name",
                JOptionPane.INFORMATION_MESSAGE);
            
            // many more JOptionPane options csn be found at:
            // https://alvinalexander.com/java/joptionpane-showmessagedialog-examples-1/
            // https://alvinalexander.com/java/joptionpane-showmessagedialog-examples-2/
        
        }
      }
}